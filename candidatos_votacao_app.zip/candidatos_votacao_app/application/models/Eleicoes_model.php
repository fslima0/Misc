<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Eleicoes_model extends CI_Model {
   public function listar() {
      $query = $this->db->get('eleicoes');
      
      return $query->result();
   }
}