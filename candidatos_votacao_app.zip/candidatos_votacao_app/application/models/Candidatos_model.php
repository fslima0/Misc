<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Candidatos_model extends CI_Model {
   public function listar($id) {
      $this->db->where('pessoa_id', $id);
      $query = $this->db->get('candidatos');

      return $query->result();
   }

   public function inserir($id) {
      $resultado = $this->db->insert('candidatos', $id);
      
		return $resultado;
   }
   
   public function pesquisarPorComarca($comarca_id) {
      $this->db->where('comarca_id', $comarca_id);
      $query = $this->db->get('candidatos');

      return $query->result();
   }
}