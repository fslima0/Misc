<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

      <form class="form-signin" action="<?php echo base_url('index.php/pessoas/votar'); ?>" method="POST">
         <h1 class="h3 mb-3 font-weight-normal">Efetuar Voto</h1>
         <select class="form-control" name="candidato_id">
            <option disabled selected="true">Candidato</option>
            <?php foreach($candidatos as $candidato) { ?>
               <option value="<?php echo $candidato->id; ?>"><?php echo $candidato->nome; ?></option>';
            <?php } ?>
         </select>
         <select class="form-control" name="eleicao_id">
            <option disabled selected="true">Eleição</option>
            <?php foreach($eleicoes as $eleicao) { ?>
               <option value="<?php echo $eleicao->id; ?>"><?php echo $eleicao->titulo; ?></option>';
            <?php } ?>
         </select>
         <br />
         <!-- Descrição do candidato com JS? -->
         <button type="submit" class="btn btn-lg btn-primary btn-block">Votar</button>
      </form>