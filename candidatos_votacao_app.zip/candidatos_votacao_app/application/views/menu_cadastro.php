<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>    

      <div class="form-signin">
         <h1 class="h3 mb-3 font-weight-normal">Menu de Cadastro</h1>
         <a href="<?php echo base_url('index.php/pessoas/cadastro'); ?>" class="btn btn-lg btn-success btn-block caixa" role="button">Representante de Grupo Operativo</a>
         <a href="<?php echo base_url('index.php/candidatos/cadastro'); ?>" class="btn btn-lg btn-warning btn-block caixa" role="button">Candidato</a>
      </div>
