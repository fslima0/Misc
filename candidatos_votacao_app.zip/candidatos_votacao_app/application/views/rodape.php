<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

      <footer class="footer">
         <div class="container">
            <span class="text-muted">Sistema de Eleição. Todos os direitos reservados</span>
         </div>
      </footer>
   </body>
</html>