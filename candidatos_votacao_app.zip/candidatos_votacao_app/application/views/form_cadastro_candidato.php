<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

      <form class="form-signin" action="<?php echo base_url('index.php/candidatos/registrar'); ?>" method="POST">
         <h1 class="h3 mb-3 font-weight-normal">Registrar Candidato</h1>
         <img src="<?php echo base_url('assets/img/user-plus-solid.svg'); ?>" height="200" width="140" />
         <input type="text" class="form-control" name="nome" placeholder="Nome Completo" required>
         <input type="text" class="form-control" name="cpf" placeholder="CPF" required>
         <input type="email" class="form-control" name="email" placeholder="Endereço de E-mail" required>
         <textarea class="form-control" name="descricao_candidato" rows="2" placeholder="Descrição do Candidato"></textarea>
         <select class="form-control" name="comarca_id">
            <option disabled selected="true">Comarca</option>
            <?php foreach($comarcas as $comarca) { ?>
               <option value="<?php echo $comarca->id; ?>"><?php echo $comarca->nome; ?></option>';
            <?php } ?>
         </select>
         <select class="form-control" name="eleicao_id">
            <option disabled selected="true">Eleição</option>
            <?php foreach($eleicoes as $eleicao) { ?>
               <option value="<?php echo $eleicao->id; ?>"><?php echo $eleicao->titulo; ?></option>';
            <?php } ?>
         </select>
         <br />
         <div class="form-group">
            <input type="file" class="form-control-file">
         </div>
         <input type="hidden" name="nivel" value="1">
         <button type="submit" class="btn btn-lg btn-primary btn-block">Cadastrar</button>
         <a href="<?php echo base_url('index.php/ouvidoria'); ?>" class="btn btn-lg btn-light btn-block" role="button">Voltar</a>
      </form>
