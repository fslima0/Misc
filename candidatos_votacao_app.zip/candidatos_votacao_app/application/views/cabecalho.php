<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!DOCTYPE html>
<html lang="pt-br">
   <head>
		<title>Eleição da Ouvidoria</title>
      <meta charset="utf-8">
      <meta name="description" content="Sistema de Eleição da Ouvidoria">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css'); ?>">
      <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
      <link href="<?php echo base_url('assets/css/styles.css') ?>" rel="stylesheet">
   </head>
   <body class="container text-center">
      <header>
         <nav class="navbar navbar-light fixed-top bg-success text-warning">
            <img src="<?php echo base_url('assets/img/DPE.png'); ?>" height="40" width="100" />
               <?php if ($this->session->userdata('logado') == TRUE): ?>
                  <div class="text-right">
                     <?php echo $this->session->userdata('nome'); ?>
                     <a href="<?php echo site_url('login/sair');?>">Sair</a> <br /> <br />
                  </div>
               <?php else:?>
               <?php endif;?>
         </nav>
      </header>

      