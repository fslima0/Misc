<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Candidatos extends CI_Controller {
	function __construct() {
		parent::__construct();
		$this->load->model(array('pessoas_model', 'candidatos_model', 'comarcas_model'));

      $this->load->view('cabecalho');
	}

	public function index() {
		$dados['eleicoes']   = $this->eleicoes_model->listar();
		$dados['candidatos'] = $this->candidatos_model->pesquisarPorComarca($sesdata['comarca']);

		$this->load->view('voto_form', $dados);
		$this->load->view('rodape');
	}

	public function registrar() {
      $nome = $this->input->post('nome');
      $cpf = $this->input->post('cpf');
      $email = $this->input->post('email');
      $comarca = $this->input->post('comarca_id');
      $candidato = $this->input->post('nivel');
      $senha = base64_encode(random_bytes(6));
      
      $pessoa = array(
		   'nome'        => mb_strtoupper($nome),
         'cpf'         => $cpf,
         'email'       => $email,
         'comarca_id'  => $comarca,
			'senha'       => $senha,
			'nivel'       => $nivel
      );
      // Fazer verificação se cadastro existe
		$pessoa_id = $this->pessoas_model->inserir($pessoa);
		
		unset($pessoa['nome'], $pessoa['cpf'], $pessoa['email'], $pessoa['senha']);

		$candidato_id = $this->candidatos_model->inserir($pessoa);
      
		$this->login->mail($pessoa);
		
		redirect('login');
	}

	public function cadastro() {
		$dados['comarcas'] = $this->comarcas_model->listar();

		$this->load->view('form_cadastro_candidato');
	}
}