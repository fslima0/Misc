<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
   function __construct() {
      parent::__construct();
      $this->load->model(array('pessoas_model', 'comarcas_model', 'candidatos_model', 'eleicoes_model'));
   }

   public function index() {
      $opcao = $this->uri->segment(3);

      $this->load->view('cabecalho');

      // Se sessão estiver ativa, retorne a página inicial do usuário
      if ($this->session->userdata('logado') == TRUE) {
         if ($this->session->userdata('nivel') == '0') {
            redirect('ouvidoria');
         }
         else if ($this->session->userdata('nivel') == '1') {
            redirect('candidatos');
         }
         else {
            redirect('pessoas');
         }
      }

      // Se não estiver logado, inicie página de login ou recuperação de senha
      if ($opcao == "recuperacao") {
         $this->load->view('form_recuperacao');
      }
      else {
         $this->load->view('form_login');
      }
      $this->load->view('rodape');
   }
   
   public function autenticar() {
      $email      = $this->input->post('email',TRUE);
      $senha      = $this->input->post('senha',TRUE);
      $validate   = $this->pessoas_model->validar($email, $senha);

      if ($validate->num_rows() > 0) {
         $dados  = $validate->row_array();

         $sesdata = array(
            'id'        => $dados['id'],
            'nome'      => $dados['nome'],
            'comarca'   => $dados['comarca_id'],
            'nivel'     => $dados['nivel'],
            'logado'    => TRUE
         );
         $this->session->set_userdata($sesdata);

         if ($sesdata['nivel'] == '0') {
            redirect('ouvidoria');
         }
         else if ($sesdata['nivel'] == '1') {
            redirect('candidatos');
         }
         else {
            redirect('pessoas');
         }
      }
      else {
         $this->session->set_flashdata('mensagem_falhou','Usuario ou senha inválidos.');

         redirect('login');
      }
   }

   public function htmlmail($pessoa) {
      $config = array(
         'protocol'   => 'smtp',
         'smtp_host'  => '10.53.49.21',
         'smtp_port'  =>  25,
         'smtp_user'  => 'eleicaoouvidoria@gmail.com',
         'mailtype'   => 'html',
         'charset'    => 'utf-8',
         'newline'    => '\r\n',
         'mailpath'   => '/usr/sbin/sendmail',
      );

      $mensagem = "
         <html>   
            <head>
               <title>Confirmaçao de Cadastro</title>
            </head>
            <body>
               <h2> Prezado(a) $nome </h2>
               <h3>
                  Obrigado por preencher seu cadastro no sistema de eleição da Ouvidoria.
                  É um prazer recebe-lo em nosso site. Seja bem-vindo!
               </h3>
               <p> Informações da sua conta: </p>
               <p> URL:   
               <p> Email: $email </p>
               <p> Senha: $senha </p>
            </body>
         </html>
      ";

      $this->load->library('email', $config);
      $this->email->initialize($config);
      $this->email->from($config['smtp_user']);
      $this->email->to($email);
      $this->email->subject('Confirmações de Cadastro - Eleição da Ouvidoria');
      $this->email->message($mensagem);

		if ($this->email->send()) {
         $this->session->set_flashdata('mensagem','Cadastro efetuado com sucesso. Verifique seu e-mail.');
		}
		else {
		   //$this->session->set_flashdata('mensagem', $this->email->print_debugger());
      }
      redirect('login');
   }

   public function recuperacao() {
      $email = $this->input->post('email', TRUE);

      $pessoa = $this->pessoas_model->pesquisarPorEmail($email);

      // Se e-mail for válido, mandar e-mail com suas credenciais
      if (count($pessoa) > 0) {
         $this->htmlmail($pessoa);

         $this->session->set_flashdata('mensagem','Usuário e senha enviado para seu e-mail.');

         redirect('login');
      }
      else {
         $this->session->set_flashdata('mensagem_falhou','Não foi possível localizar e-mail do usuário.');

         redirect('login/index/recuperacao');
      }
   }

   public function sair() {
      $this->session->sess_destroy();

      redirect('login');
   }
}