<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pessoas extends CI_Controller {
	function __construct() {
		parent::__construct();
		$this->load->model(array('pessoas_model', 'comarcas_model'));

      $this->load->view('cabecalho');
	}

	public function index() {

	}

	public function registrar() {
      $nome = $this->input->post('nome');
      $cpf = $this->input->post('cpf');
      $email = $this->input->post('email');
      $comarca = $this->input->post('comarca_id');
      $nivel = $this->input->post('nivel');
      $senha = base64_encode(random_bytes(6));
      
      $pessoa = array(
		   'nome'        => mb_strtoupper($nome),
         'cpf'         => $cpf,
         'email'       => $email,
         'comarca_id'  => $comarca,
			'senha'       => $senha,
			'nivel'       => $nivel
      );
      // Fazer verificação se cadastro existe
      $pessoa_id = $this->pessoas_model->inserir($pessoa);
      
		$this->login->email;
		
		redirect('login');
	}
	
	public function cadastro() {
		$dados['comarcas'] = $this->comarcas_model->listar();

		$this->load->view('form_cadastro_pessoa', $dados);
	}
}
